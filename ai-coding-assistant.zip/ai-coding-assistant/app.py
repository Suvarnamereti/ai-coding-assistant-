import streamlit as st
from assistant import CodingAssistant

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="AI Coding Assistant",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
  /* Base */
  html, body, [data-testid="stAppViewContainer"] {
      background: #0d1117;
      color: #e6edf3;
      font-family: 'Inter', sans-serif;
  }
  [data-testid="stSidebar"] {
      background: #161b22;
      border-right: 1px solid #30363d;
  }
  /* Header */
  .hero {
      text-align: center;
      padding: 2rem 0 1rem;
  }
  .hero h1 {
      font-size: 2.6rem;
      font-weight: 800;
      background: linear-gradient(135deg, #58a6ff 0%, #bc8cff 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin-bottom: 0.25rem;
  }
  .hero p { color: #8b949e; font-size: 1rem; }
  /* Mode cards */
  .mode-card {
      background: #161b22;
      border: 1px solid #30363d;
      border-radius: 10px;
      padding: 0.9rem 1.1rem;
      margin-bottom: 0.5rem;
      cursor: pointer;
      transition: border-color 0.2s;
  }
  .mode-card:hover { border-color: #58a6ff; }
  /* Output area */
  .output-box {
      background: #161b22;
      border: 1px solid #30363d;
      border-radius: 10px;
      padding: 1.2rem;
      margin-top: 1rem;
  }
  /* Badge */
  .badge {
      display: inline-block;
      background: #1f6feb33;
      color: #58a6ff;
      border: 1px solid #1f6feb;
      border-radius: 999px;
      padding: 0.15rem 0.7rem;
      font-size: 0.75rem;
      font-weight: 600;
      margin-bottom: 0.6rem;
  }
  /* Button override */
  div.stButton > button {
      background: linear-gradient(135deg, #1f6feb, #8957e5);
      color: white;
      border: none;
      border-radius: 8px;
      padding: 0.55rem 1.6rem;
      font-weight: 600;
      width: 100%;
      transition: opacity 0.2s;
  }
  div.stButton > button:hover { opacity: 0.88; color: white; }
  /* Selectbox / textarea */
  .stSelectbox > div, .stTextArea > div > textarea {
      background: #161b22 !important;
      border: 1px solid #30363d !important;
      color: #e6edf3 !important;
      border-radius: 8px !important;
  }
  /* Divider */
  hr { border-color: #30363d; }
</style>
""", unsafe_allow_html=True)

# ── Init assistant ────────────────────────────────────────────────────────────
@st.cache_resource
def get_assistant():
    return CodingAssistant()

assistant = get_assistant()

# ── Session state ─────────────────────────────────────────────────────────────
if "history" not in st.session_state:
    st.session_state.history = []

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🤖 AI Coding Assistant")
    st.markdown("---")

    mode = st.selectbox(
        "Select Mode",
        options=[
            "Code Generation",
            "Code Explanation",
            "Bug Detection",
            "Code Optimization",
            "Code Conversion",
            "Documentation Generator",
            "Unit Test Generator",
        ],
        index=0,
    )

    st.markdown("---")

    # Language selector (shown for relevant modes)
    language = st.selectbox(
        "Target Language",
        ["Python", "JavaScript", "Java", "C++", "TypeScript", "Go", "Rust", "SQL"],
        index=0,
    )

    if mode == "Code Conversion":
        target_language = st.selectbox(
            "Convert TO",
            ["JavaScript", "Python", "Java", "C++", "TypeScript", "Go", "Rust", "SQL"],
            index=0,
        )
    else:
        target_language = None

    st.markdown("---")
    st.markdown("### 📖 Mode Guide")
    guides = {
        "Code Generation":       "Describe what you want and I'll write the code.",
        "Code Explanation":      "Paste any code and I'll explain it clearly.",
        "Bug Detection":         "Paste buggy code and I'll find & fix the issues.",
        "Code Optimization":     "Paste code and I'll suggest performance improvements.",
        "Code Conversion":       "Paste code and choose a target language above.",
        "Documentation Generator": "Paste a function/class and I'll write its docs.",
        "Unit Test Generator":   "Paste a function and I'll generate pytest test cases.",
    }
    st.info(guides[mode])

    if st.button("🗑  Clear History"):
        st.session_state.history = []
        st.rerun()

# ── Main layout ────────────────────────────────────────────────────────────────
st.markdown("""
<div class="hero">
  <h1>🤖 AI Coding Assistant</h1>
  <p>Generate · Explain · Debug · Optimize · Convert · Document · Test</p>
</div>
""", unsafe_allow_html=True)

left, right = st.columns([1, 1], gap="large")

with left:
    st.markdown(f'<div class="badge">{mode}</div>', unsafe_allow_html=True)

    placeholder_map = {
        "Code Generation":        "Describe the function or program you want to build...\n\nExample: Write a Python function that checks if a number is prime.",
        "Code Explanation":       "Paste the code you want explained here...",
        "Bug Detection":          "Paste your buggy code here and I'll find the issues...",
        "Code Optimization":      "Paste the code you want to optimize...",
        "Code Conversion":        f"Paste your {language} code here to convert it...",
        "Documentation Generator":"Paste the function or class to document...",
        "Unit Test Generator":    "Paste the function you want tests generated for...",
    }

    user_input = st.text_area(
        "Your Input",
        height=280,
        placeholder=placeholder_map[mode],
        label_visibility="collapsed",
    )

    clicked = st.button("⚡ Run Assistant")

with right:
    st.markdown('<div class="badge">Output</div>', unsafe_allow_html=True)
    output_placeholder = st.empty()

# ── Processing ─────────────────────────────────────────────────────────────────
if clicked:
    if not user_input.strip():
        st.warning("Please enter some input first.")
    else:
        with st.spinner("Thinking…"):
            result = assistant.run(
                mode=mode,
                user_input=user_input,
                language=language,
                target_language=target_language,
            )

        st.session_state.history.append({
            "mode": mode, "input": user_input, "output": result
        })

        with right:
            if "```" in result:
                # Extract prose + code blocks
                parts = result.split("```")
                for i, part in enumerate(parts):
                    if i % 2 == 0:
                        if part.strip():
                            st.markdown(part.strip())
                    else:
                        lines = part.split("\n", 1)
                        lang_hint = lines[0].strip() if lines else ""
                        code_body = lines[1] if len(lines) > 1 else part
                        st.code(code_body, language=lang_hint or "python")
            else:
                st.markdown(result)

# ── History ───────────────────────────────────────────────────────────────────
if st.session_state.history:
    st.markdown("---")
    st.markdown("### 📜 Session History")
    for i, item in enumerate(reversed(st.session_state.history), 1):
        with st.expander(f"#{len(st.session_state.history) - i + 1} · {item['mode']}"):
            st.markdown("**Input:**")
            st.code(item["input"], language="text")
            st.markdown("**Output:**")
            st.markdown(item["output"])
