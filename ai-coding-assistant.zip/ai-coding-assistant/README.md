# 🤖 AI Coding Assistant

> An AI-powered developer productivity tool built with Python, OpenAI GPT-4o, and Streamlit.

[![Python](https://img.shields.io/badge/Python-3.11+-3776AB?style=flat&logo=python&logoColor=white)](https://python.org)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.35+-FF4B4B?style=flat&logo=streamlit&logoColor=white)](https://streamlit.io)
[![OpenAI](https://img.shields.io/badge/OpenAI-GPT--4o-412991?style=flat&logo=openai&logoColor=white)](https://openai.com)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

---

## ✨ Features

| Feature | Description |
|---|---|
| **Code Generation** | Describe what you want in plain English → get working code |
| **Code Explanation** | Paste any code → get a clear, step-by-step explanation |
| **Bug Detection** | Paste buggy code → get identified bugs + fixed version |
| **Code Optimization** | Paste code → get performance and readability improvements |
| **Code Conversion** | Convert code between 8+ programming languages |
| **Documentation Generator** | Auto-generate docstrings and API documentation |
| **Unit Test Generator** | Generate pytest test cases with full edge case coverage |

---

## 🚀 Quick Start

### 1. Clone the repository
```bash
git clone https://github.com/YOUR_USERNAME/ai-coding-assistant.git
cd ai-coding-assistant
```

### 2. Create a virtual environment
```bash
python -m venv venv
source venv/bin/activate      # Linux / macOS
venv\Scripts\activate         # Windows
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Set up your API key
```bash
cp .env.example .env
# Open .env and replace "your_openai_api_key_here" with your real key
```

Get your API key at [platform.openai.com](https://platform.openai.com/api-keys).

### 5. Run the app
```bash
streamlit run app.py
```

Open [http://localhost:8501](http://localhost:8501) in your browser.

---

## 📂 Project Structure

```
ai-coding-assistant/
├── app.py                  # Streamlit UI
├── assistant.py            # Core AI logic & LLM integration
├── prompts/
│   ├── __init__.py
│   └── templates.py        # Prompt templates for all modes
├── tests/
│   ├── __init__.py
│   └── test_assistant.py   # pytest test suite
├── requirements.txt
├── .env.example            # Environment variable template
├── .gitignore
└── README.md
```

---

## 🧪 Running Tests

```bash
pytest tests/ -v
```

---

## 🌐 Deployment

### Streamlit Community Cloud (Free)
1. Push your repo to GitHub
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Connect your repo → set `API_KEY` in Secrets
4. Deploy!

### Render / Railway
```bash
# Start command:
streamlit run app.py --server.port $PORT --server.address 0.0.0.0
```

---

## 🧠 How It Works

```
User Input
    │
    ▼
Mode Selection  ──►  Prompt Template
                           │
                           ▼
                    OpenAI GPT-4o API
                           │
                           ▼
                  Structured Response
                           │
                           ▼
                   Streamlit UI Display
```

1. **Prompt Engineering** — Each mode uses a carefully crafted system prompt that instructs the LLM on the exact task, format, and quality bar expected.
2. **LLM Integration** — Calls the OpenAI Chat Completions API with low temperature (0.3) for consistent, accurate outputs.
3. **Streamlit UI** — A clean dark-themed interface with session history, mode switching, and language selection.

---

## 🗺 Roadmap

- [ ] GitHub repository upload & analysis
- [ ] Code complexity scoring (cyclomatic complexity)
- [ ] Multi-file project support
- [ ] Real-time streaming responses
- [ ] AI Pair Programmer (chat mode)
- [ ] Pull request review automation

---

## 💼 About This Project

Built as a portfolio project demonstrating:
- **Generative AI** — LLM integration, prompt engineering, context management
- **Python** — OpenAI SDK, environment management, modular architecture
- **Software Engineering** — Code analysis, debugging, refactoring, documentation
- **Deployment** — Streamlit, environment configuration, cloud deployment

---

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.

---

## 🙏 Acknowledgements

- [OpenAI](https://openai.com) for the GPT-4o API
- [Streamlit](https://streamlit.io) for the UI framework
