from .templates import PROMPTS

__all__ = ["PROMPTS"]
