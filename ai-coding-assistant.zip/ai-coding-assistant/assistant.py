"""
assistant.py — Core AI logic for the Coding Assistant.
Wraps the OpenAI-compatible API and dispatches to mode-specific prompts.
"""

import os
from openai import OpenAI
from dotenv import load_dotenv
from prompts.templates import PROMPTS

load_dotenv()


class CodingAssistant:
    """Unified AI Coding Assistant supporting multiple developer workflows."""

    def __init__(self, model: str = "gpt-4o"):
        api_key = os.getenv("API_KEY")
        if not api_key:
            raise EnvironmentError(
                "API_KEY not found. Please create a .env file with API_KEY=<your key>."
            )
        self.client = OpenAI(api_key=api_key)
        self.model = model

    # ── Public interface ──────────────────────────────────────────────────────

    def run(
        self,
        mode: str,
        user_input: str,
        language: str = "Python",
        target_language: str | None = None,
    ) -> str:
        """Dispatch user request to the appropriate prompt handler."""
        prompt = self._build_prompt(mode, user_input, language, target_language)
        return self._call_llm(prompt)

    # ── Individual mode helpers (also callable directly) ─────────────────────

    def generate_code(self, description: str, language: str = "Python") -> str:
        prompt = PROMPTS["Code Generation"].format(language=language, input=description)
        return self._call_llm(prompt)

    def explain_code(self, code: str) -> str:
        prompt = PROMPTS["Code Explanation"].format(input=code)
        return self._call_llm(prompt)

    def detect_bugs(self, code: str) -> str:
        prompt = PROMPTS["Bug Detection"].format(input=code)
        return self._call_llm(prompt)

    def optimize_code(self, code: str, language: str = "Python") -> str:
        prompt = PROMPTS["Code Optimization"].format(language=language, input=code)
        return self._call_llm(prompt)

    def convert_code(self, code: str, from_lang: str, to_lang: str) -> str:
        prompt = PROMPTS["Code Conversion"].format(
            language=from_lang, target_language=to_lang, input=code
        )
        return self._call_llm(prompt)

    def generate_docs(self, code: str, language: str = "Python") -> str:
        prompt = PROMPTS["Documentation Generator"].format(language=language, input=code)
        return self._call_llm(prompt)

    def generate_tests(self, code: str, language: str = "Python") -> str:
        prompt = PROMPTS["Unit Test Generator"].format(language=language, input=code)
        return self._call_llm(prompt)

    # ── Private helpers ───────────────────────────────────────────────────────

    def _build_prompt(
        self,
        mode: str,
        user_input: str,
        language: str,
        target_language: str | None,
    ) -> str:
        template = PROMPTS.get(mode)
        if template is None:
            raise ValueError(f"Unknown mode: {mode!r}")

        kwargs = {"input": user_input, "language": language}
        if target_language:
            kwargs["target_language"] = target_language
        return template.format(**kwargs)

    def _call_llm(self, prompt: str) -> str:
        """Send prompt to the LLM and return the response text."""
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "You are an expert AI Coding Assistant. "
                            "Provide accurate, well-structured, and concise responses. "
                            "Always include code blocks with correct syntax highlighting. "
                            "When detecting bugs, clearly label them and provide fixes."
                        ),
                    },
                    {"role": "user", "content": prompt},
                ],
                temperature=0.3,
                max_tokens=2048,
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            return f"❌ **Error calling the LLM:** `{e}`\n\nCheck your API key and internet connection."
