"""
tests/test_assistant.py — Unit tests for prompt building and assistant logic.
Run with: pytest tests/ -v
"""

import pytest
from unittest.mock import MagicMock, patch
from prompts.templates import PROMPTS


# ── Prompt template tests ──────────────────────────────────────────────────────

class TestPromptTemplates:
    """Verify all prompt templates exist and render without errors."""

    MODES = [
        "Code Generation",
        "Code Explanation",
        "Bug Detection",
        "Code Optimization",
        "Code Conversion",
        "Documentation Generator",
        "Unit Test Generator",
    ]

    def test_all_modes_present(self):
        for mode in self.MODES:
            assert mode in PROMPTS, f"Missing prompt template for: {mode}"

    def test_code_generation_renders(self):
        prompt = PROMPTS["Code Generation"].format(
            language="Python",
            input="Write a function to reverse a string.",
        )
        assert "Python" in prompt
        assert "reverse a string" in prompt

    def test_code_explanation_renders(self):
        code = "for i in range(5): print(i)"
        prompt = PROMPTS["Code Explanation"].format(input=code)
        assert code in prompt

    def test_bug_detection_renders(self):
        code = "numbers = [1,2,3]\nprint(numbers[5])"
        prompt = PROMPTS["Bug Detection"].format(input=code)
        assert "numbers[5]" in prompt

    def test_code_conversion_renders(self):
        prompt = PROMPTS["Code Conversion"].format(
            language="Python",
            target_language="JavaScript",
            input="def add(a, b): return a + b",
        )
        assert "Python" in prompt
        assert "JavaScript" in prompt

    def test_unit_test_renders(self):
        prompt = PROMPTS["Unit Test Generator"].format(
            language="Python",
            input="def is_prime(n): pass",
        )
        assert "pytest" in prompt


# ── Assistant dispatch tests (mocked LLM) ─────────────────────────────────────

class TestCodingAssistantMocked:
    """Test assistant mode dispatch with a mocked OpenAI client."""

    @pytest.fixture
    def assistant(self):
        with patch.dict("os.environ", {"API_KEY": "test-key"}):
            with patch("assistant.OpenAI") as MockOpenAI:
                mock_client = MagicMock()
                mock_response = MagicMock()
                mock_response.choices[0].message.content = "Mocked LLM response"
                mock_client.chat.completions.create.return_value = mock_response
                MockOpenAI.return_value = mock_client

                from assistant import CodingAssistant
                return CodingAssistant()

    def test_generate_code(self, assistant):
        result = assistant.generate_code("reverse a string", "Python")
        assert isinstance(result, str)
        assert len(result) > 0

    def test_explain_code(self, assistant):
        result = assistant.explain_code("for i in range(5): print(i)")
        assert isinstance(result, str)

    def test_detect_bugs(self, assistant):
        result = assistant.detect_bugs("print(numbers[5])")
        assert isinstance(result, str)

    def test_optimize_code(self, assistant):
        result = assistant.optimize_code("def f(n): return [i for i in range(n)]")
        assert isinstance(result, str)

    def test_convert_code(self, assistant):
        result = assistant.convert_code("def add(a,b): return a+b", "Python", "JavaScript")
        assert isinstance(result, str)

    def test_generate_docs(self, assistant):
        result = assistant.generate_docs("def is_prime(n): pass")
        assert isinstance(result, str)

    def test_generate_tests(self, assistant):
        result = assistant.generate_tests("def is_prime(n): pass")
        assert isinstance(result, str)

    def test_invalid_mode_raises(self, assistant):
        with pytest.raises(ValueError, match="Unknown mode"):
            assistant.run(mode="Invalid Mode", user_input="test")


# ── Standalone helper ─────────────────────────────────────────────────────────

def test_is_prime():
    """Validate the canonical is_prime example from the project spec."""
    def is_prime(num):
        if num < 2:
            return False
        for i in range(2, int(num**0.5) + 1):
            if num % i == 0:
                return False
        return True

    assert is_prime(2) is True
    assert is_prime(7) is True
    assert is_prime(13) is True
    assert is_prime(1) is False
    assert is_prime(0) is False
    assert is_prime(9) is False
    assert is_prime(100) is False
